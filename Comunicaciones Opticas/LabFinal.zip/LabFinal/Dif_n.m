function Delta = Dif_n(n1,n2)
Delta = (n1^2-n2^2)/(2*n1^2);
end

