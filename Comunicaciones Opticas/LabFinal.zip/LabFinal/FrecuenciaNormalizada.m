function [V] = FrecuenciaNormalizada(a,NA,Lambda)
V = (2*pi*a*NA)/Lambda;
end

