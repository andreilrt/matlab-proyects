function [B] = LambdaFrecuencia(A)
c = 3e8; %Velocidad de la luz
B = c/A;%Lambda o Frecuencia
end

