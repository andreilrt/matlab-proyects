function LT = Longitudinal(NA, s, a)
LT = -10*log10(1-((s*NA)/(4*a))); %Se tiene en cuenta el indice n1 ?? o no?
end

