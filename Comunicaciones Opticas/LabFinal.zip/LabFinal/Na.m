function NA = Na(n1,n2)
    NA = sqrt((n1^2)-(n2^2));
end

