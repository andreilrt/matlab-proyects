function Pes = PES(IS,RL)
Pes = IS^2*RL;
end

